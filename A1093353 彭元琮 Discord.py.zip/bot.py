from email import message
import discord
client = discord.Client()
@client.event

async def on_ready():
    print(f'目前登入身份:{client.user}')
    
@client.event
async def on_message(message):
    if message.author == client.user:
      await message.channel.send('123!!')
    return
    if message.content == '我的報告結束了':
        await message.channel.send('謝謝!!')
        
client.run('OTY4NDc3OTA5MTg0NTQ0Nzk4.YmfbVg.pTnmYnIVGtofP9POmyN9kEyl4Ys')